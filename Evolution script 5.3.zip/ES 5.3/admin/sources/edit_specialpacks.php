<?php //00df8
// *************************************************************************
// *                                                                       *
// * EvolutionScript.com                                       			*
// * Copyright (c) EvolutionScript.com All Rights Reserved,                *
// * Release Date: March 13th 2017                                         *
// * Version 5.3                                                           *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Website: http://www.evolutionscript.com                               *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only  in  accordance  with  the  terms  of such  license and with the *
// * inclusion of the above copyright notice.  This software  or any other *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license.  EvolutionScript may terminate this license if you don't     *
// * comply with any of the terms and conditions set forth in our end user *
// * license agreement (EULA).  In such event,  licensee  agrees to return *
// * licensor  or destroy  all copies of software  upon termination of the *
// * license.                                                              *
// *                                                                       *
// * Please see the EULA file for the full End User License Agreement.     *
// *                                                                       *
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpQLxTMPNTOQ541uzXtQ5mypatPzHSsdkyUE2Bog2gNkOd/Up2vC5fViKKsmKjWh2zxVY53p
xlZS49wmcQh/SWRtjfXCGtkq3Alzq6+wTvZj8Txsfr0cnis3OZqfml0M2ApcN+m/K/Bk8BL6Gh8w
j/asTYW8BgvZQYYiy3a39fVMTjy1bOedj+/lqHTgLPo8Xqev+WFcCqFNvF7u8w3K0fH47nkxYBC2
WvmvM48KWRWcca5E0r2siTDA3C2dktLSJyxpaiZXujCauv8I4+FqsZlHpua1lVji9FplrI0QYKeO
zlb+udMkOmBYIKbsLGAENhJ5uY9X8LldD6Pyzd+EmZdKatosgW0d/en2yEcoTiXjL3hs0zwxtxkk
r9XrA41z/UQRz44rhVqidqRgqRnerjBk/kSjwgwyHdJx9racH6Q1f4Qz6Jd++P6Gg8BzozKizJNl
gCTT8eBv63XQDmcHMQPZPK2A2B+mjhT4vgNVVfWpC9ZOIYczPdUy6/RJyaIWAnarIo7F2G8tZAhu
+my1yWWsgvZOJcI9gfTXpcFz7x0C2xJcBn8CMTEhY1JtbDGqwN4GqKw3ydZh5NM2MwqiBeqoxqhi
4fqZjXQVjDpt/95E4bzTMpstU7mC/6HDNKbOgSCs7bR5vhiARZDcpX6uq0mAXqf4Am4SGZNSSV/+
WZWmlOKW/p4728zWKrLF83yu5SjaKfZmBsPtsUEQ3edP6hT2IEvQBgnaHKWrKTBO5szs4caUcIH5
zsXZLchV0K4UUsgdwczLOD2JAsgJnDwoS+tX66FvtoypNvD5aH699qX4/t+eXCxiHuFLxAkW2XDr
fZsLaom0zUPyz1keT7VgfO+nyBUHJSzYA+dmy9pNPEdI5RRECmXLhJbi3ExUiUdb4mUbgHy7qnRk
7RWjjUsGWzJl+uA8MxT5AW+9Q7j9Ngjzhye+DHC/u+TUQT8QP3T73w3YdAPWcr42HRMO5cy/PRXS
Q5b4fdvOQeaTW7AoJs39gqWcFUEm0G20v+fw5SgxtsQ951pQzOfrxI0see+pUVB2wPhrLC+29iyN
3BXH7DnmXiXfllCNekLmERg2mVHiGe5bk6KoOPUHzw4iTmrUz4cBbaJD9aPazsylK8bPPUf5zb8F
BK4A7lHw4U3o3rc0qv96ZCKDrsIjgN4t0r+CPKHTcUqN8qRdMlBQ9Mwdw27fxI1Ic2ILgxDocinP
c3qqvnUlz+J7eFCZAy1cughf1aNQ/cK8sErZMIaKv3TYp3DLKri22lZ3pHver9kunOt4AnkQU0Qx
G2B+ZY2TrkU68oCGLrcBHQreLDTTmn9X6TeE+vvZHagKomqP8AdmcxiEFKDpIElLgiLMwX7U8eoK
Zwk8osR/wZgYs9iAAPBPJoE5ORYj9n3z3NoVXqql4ej3sQ90SZ/x8/1+iUCfVKjLnQU8QOzlB8Rk
5k+mneEq7LND4GXnuUDJFXze5Y5z/85mf4Xgdv35p6GFsWlPBxkElbHQ5NRQbDT6280AxUZuRxy7
X5xga797zOoOJRINT8kXEsweEEJaaZTX7MV9yQpPPJy8P5Rsy78sZLxU5JIsRxctsAxbvwYidBoD
uLETJQezj4wh9qP6jNA/rKDOEDpOepP0/5C7hlRB0VOF1m1qpGfayAX/9512RB2UVlRzXTZGwFBr
pQwp2rfO/4LQP72Ai6zHWTouQibFobBefDtFzDPEOl37KC5VFlZ00Z6p3VqbutcGGEoGJXDpC5ow
VLKdXP4lJzf4PdUj+AS/OPyttO3NObuQwpf8latcIu+1n4zej8B11CsiC3+W6vLnucMUa8j+V3L/
QXvmhUUof31WLdAYGpinDBo6wQBfctCXnIDFOX+GYt8oqPViYLyjgiocu5tX6kz7CaorksA+Cy/n
N8n7aUwKzeCjz7RpPqNw3MBpi5S4bJCkvGOIg1GoJHHPxDJYjf2d0SM9ldyY7raDrjnWZkKgHaok
aCeTFLB411vrJQx3azHb9hH70s9E+cj9cpAcVt45t/33+GNjtcKlH1Vr3aKwOFKXGoS/YGYW5LUj
ZwpEEwt6CXeW9o23NAkWtSlgo2ETbi0cBBvpMY3PAytY61+oclGLxD3hqjcTA4mXQe3OAjTdtayQ
6fKEsV/uqMNjXx0GuGCGeYq8GOcZh+dIfgykYc/m1tMpkF62iYopcXcQi6LCvMFj9X548dhJtoD9
HzZrQMb+utlz6cJRx1fkVBtwObwV93O4HMXstvF1u2+E9DvbucmU5LV3ETJLLe4qICGMyR8p59lw
qBVDhHwOOyU0djw8Hoc5t5S5G7TfmyEE0nm//9ZVuW9PlrMfcQysRMdsuBtcWWKU2/Xzj4Q5qwEI
rnMCIW/Ppqd6E+nzDpeEV9umR1LhoIGH3LiRaXT5PDD81GM299FW0oPJqxLxkYkV7QjYPfvCkhtS
T+cJhjB7coT5gzPbWLRc/KFq9BPvu3++FfD2ddHKXIK4VickPlnkg48qB8fACuwVdt0CgMEixWaH
BGsY8Apv1clax9Q6yXG6fCyCJ65LbB0YLfezyFLU/WfqrbJDGfvtc05kKuws2fIjnGEXxhpFBO79
wp4KDM4jUNPXaRvuVEDYiRpJxnv2+IbrToLORbEIXWrh1C7QJlQolwwIGZbA1Nl9I8G+L2zTWlHU
JQMnI7DdXu5vnfTcfBzk1aVVh/Grp7QIibjBx36kW2Xsdo088zF7dKCC22VyFiqDr4FKbs7XRMk6
eMfkvABeJoHEZu5IeFgzcI+EWX3eL6K4WAH2/K0NfLxajkJX/gk5RRMpDdV+/Q+rCYT/TAqzfaek
Q/oC26O5J0T5H0qHtBUMqvKu9BYsGDeeaIlSrHTU8AGppuipnm5mLmDfjYxR8fnsydN90ieQZMib
dgiu+jGPSWxFM9HfLPaHxZPsJP3CCTIvcgM25Tb4BNCGiLxbyq08tsvjEGrpQXzzbDd5/txgQXNk
w+FpmUyB43Q6aXQj3LicQ72sT/u7xoOKrT8/LDMeCyNfBMi4iklhM84chPEGAmwn4ZvOf+BVxQ8N
oGfykWF2JM+kiPK+OLxlEcAkIRYdk9HDdi8CXBPe4ZulTFGs9E+3lgL3wbmbTS2F1uWn90yF//rv
OkRrbNa8OKxjdn8AA1FaND4Jc3VGoRk3vS0pw0yrxanm8FBcKqO5ZPbtaL0lLn+/E60+bxpqGqRp
+WulRqbRhSeiFb2RbG5UHtB49HjZj0yB+SG4QOBJlx4etak0qsA5mBE5/0aoGJXuO4uwFaidRObH
+xcyB/F/3RoLOyt79MBJag6CEWeIPYTPFYoicB1YZHacz/9k8u9uEDSpSA/0cr3/BOdUTTm/Olfp
MmKclvf/cEjTvol34n8xbmJkR/EninGWEBCwI16cdR1mJTjbucCl1NHBAit7X5OSSRUnvwb7MR7D
tRNHc6ITDQke+YCQn2xNOK24nbhD9S9ITbc0ig8k5gum90ICkop+Gi6aU43sopLwIXHdBv53bRHD
NikJ0bjBR2kJITToNGVxaUlfvecGaRS77Hb9hWZS21iYcg0DcJWBX45XCzfKnTugV6OBaviwtLtT
XwUKL+3SZsoDNGS0Rj4NmOTyJJE/sUGqsUkgpOjtHiiY3BiJ8ztsOakPy6X+saTa8UQbVjhRLct0
HijgBzuZa00P0pwszNiBlt8dCqjinoz4PwF8z7fe8jOJbVjaCxVwH3QEDklwKK8bh438FvzAVxw9
uWOmj96INcKKPi7hdhWYv7RAWPGDyVydLioxG6gD/jRUnyiFihsW3Kq/YVFZV74ml35THlmTE1E0
Rl+uRxrTbeaMNr791cNT++lR+XE8ifLHY+cBNJZBQM1b+JSuMRXtrd6ywl6nHg0SUgiJ7X0vkWiU
SmIGlWreulyjoWmg5bU2T8jFkKEWDgyh+V8sAM3QpCUrJIcjnRXyD1znGjdj221OAK8nWYgo/7SV
gZR3r291qdLuE3PPIY2jqh1Gl97H3Nz/jun+o6vE/58rTw3IB6moArXFIxAKPiFI01xyb9RY6y8w
+PyQ2sj7V+uAcGX+8SVvKlZCzmsIoR5yI19evrr2sX3P2gt7CHl4MtKo6JZWuBgGdsyRTi8JbDTD
kOgdR4hJIopP8p+3sd69HOkR6Qx0/8w5RmMo6t1p/xp/bF1mvHBwgJRP4Unpd808AMA/0BZoRw4u
o7Lr41JK7YTW+bjCfPKhCzHuWyOaOc1CFt4re7FYzQ6HRXt+l2GPpb3Agg8w+luknOaqkSGHnfmd
c9wIZlG77r+rSmfPeb9SD+9iuJ/wOs047PbfAq0Ov4lxIY4UoMNbqP0BTUriMp8fcMdJjQRPY/gd
EB6h8gLaHkgJTeqmJ2n1mRQwCWjatv/M5EyWNjA2tgTRZFcyXDx/jBjp5I+X1uRVjcjnWB/qi/WX
eQta8RhRKXbc8XrXjEko6uysVfOdfOkygjrU0dF5OUFGjb0fsVU3+Upsxmz5opgLlfDNTS9EUW9v
Em3/ltZ9nRcy0M41MVGQbqWYtaRFKWsqeOqIulUPTyXM/wU8NiIOPRS8p2XC+FK5xHAjjiD5SuFP
shNHebxoX4YFyIZWBR8I3oq3+8sp7Fl/Dlq6BCHtV54SVQmLGu1gDXlYj4SgDs5RG1YAxfr2ZUZC
573uEUU2kZuBMVDn4rxLOeyGVTQWti0+ez5dbknVVcwG3z+TAwc9ZhGMdYsFMCSBXj1/5iZYqyrO
yAPlIBe8xyzcHzW45lPDOKpLWf2tEZL4QjoC7azBTbBGjQ0hT8gqvVaOMRUE58DUqZjbYxAQ8jPb
odk57CPoPRVRmgQA1e/9sLaGl2V4lTVlWPWKSNRc0kMYGOzT46Tlp5ZGMqkwMF9j2GG+E2Ue3uNE
nevcYQdo1YCV4t93knIx19BfRf2ncKszgJ9kXH6VjzWpweHj2+4Zx8HNTF4eHO9vWroJKsXy5tYs
YqDUIdukdejv9VMFqbtMUuQ79frXZro3VYgdqp6VoYpPgx3BalUG5NNq/HIsUXLTGANR3Ta57Rxd
m8X3tGqmHCkx2GY1cr3xGJ6lPybYfJcIK5irgihm4qP6uLjRvCj5s3s4rmsvjOzOQ7ae9P925XfB
SKO9NtDldgGUvaLQwpANXv/mqqQINApNbUTWLjuo09CwWkKO6Gy6yTMVS5tpKggCrXOSbdN1f60u
s5CICf5//qZDTsfxLh3eAXZ51HqO0WS5XIjbpxBRFTjIiokmORUmYH+Bp8n/06l+kG59HeshUh+9
YkE20PD1+zBr30ecBejtwxgNyjpXGBcJPXyWnkRGBCRzVbWjGCmxN4+5odG3sclVNNdqLoOWW4lT
VVNzrnYWJgedd031r+4OzkQ75NHDcN5pmyoBKLxU6JDLH6ilxFmO7dLTlhi1JVMOMKA9IL55uTHd
qLakt2wv/z9NKPlluHZ8YABhWB6N5zcAKLJaZw4oN1FOmr6CHpgL4yCmCiClZYTHgYihYyly5otz
ku1egoKBm39Q0zyrzBtqf6niYlbW4HcHAAzKSKJbZMOTfnx/Xk6lj/7g3p88xYUyv0wi5pJHwCKR
jB+WXkWUytLX3QGZB0PfZHQWMRnoYVFzOyjsHcAUcSX7y0LcN8pLK0SROEtqh1Lam264tKNfM5QK
Bz+cEqd8fz4SVieBIIppwfdXFisB21YJj3RrIa7S/HaPWfTukzF7dZ42EYgDeFJqZWU1O2Jv9Dvz
GJzu+UF8snapQFPazKVRO70WRaN31JBflze2W1kOOX/jU38rk0jqCtSYMZa3qeww4qB98+A9NtQl
/3K54Gzm1GdJ/PnpUz0VJRlaXztSRDOdzkBcjQ671J0V6VE7RDhvNQoVgWACyNgAolQeTE9Gy4zY
aIanzgwyISaB432ZhKnAR6kW27HqY2sqOu5NJWq/7bgywBxSZBw289o/1IgCCgm5eRwK4n5UJ8bt
rRRjzlwFjNWQ96Cu3krteM39lhP1Khd7FudsY7UCeKXWUl6EaMOh3IljKqdBeGIFjnVhD8QX0OcK
6U65qeVvjArR+IK4DQBYiWEFawIgEH1aR9LwIaQt1+DMJ4PgXqIbpibh4OtP+baKiSNHuAD4fvla
HGbo10Wbau36SnarAT6QNMMOxiJBS+JiZCkXClziH1bYSbw0CqQ965OrwpJr8Fo4vsksu76T4uNw
eht4kwClDw/BlJG0EpeHawxJKB5k95UgFu4jdUVEgGi5SPEua/zMTtqSTGTeGfQDydhGE5flmlsX
9NIosJ0RxSa8cRknRiq6SixFNys0X0kQV/rd9/LKZO+CuZbDIQgw27bbm1rUqik0HexN4pw3qj5K
/UN1/QKDsht152gIVGSG/y3xbum0akK3J4Q2n1ju2makHHp96gFTDXasmQyUbW8ZXqbcPbfMZaKW
41ZRJD09x9I0mddbfcgILX1GGHmbxjcQ++DhvLJbCUyCSYtVYMN3auWhrK9D9G1hNYCMJd9p/wTC
bzzF+gMkgASR/K8kVJw0J9VkXrzvMaYvFRZpfnpm6qDIDesND2ugId6rnhAAW8JR2ySVJ9mp4AKq
WrexyfpQRdm7PVHhP7t/LDCbLCxpEUbaWyovtdQ4gZdErYJFSw4vXTDeN5oqa4MFFMXc/UOQh6m0
MY9QPr3FNWCg7u0jVxgKCMQJUg5t2fa/eSrxbd115gvvO1YlsIUCZ/0mkglrRpHp0G5AIqGOit5C
pqu+bO7SyV8d58SXsQUda5Kv+QBe3B7QenpESYJDqQvByE8gqeLNwGwsVDcOJq+t/YLUnJz49cC3
Tf3bgu53dBtSpfr8+B2WLcc6UN8K7zW01lxcDWF1/ahoKxUYySiNp90bUI3lyxAuSE6No4vKS1B1
DgCGgsFE+HZ5AxrErJIvFNEhlZK3BEt4kt7xqIxsOIbean71YGLLR5yWTFypEg66gYMavqKxRBd9
d9bbbxl9hX791Pfhfg4LcCe7XVkXBSDGYuWimdX43NGF+1HQctsiIwaoA0XeVYZsFTK2qlX3K4Mz
Fya9pKe0ngttE4rAHxCRp5gTgpI5mc7SW+NKw54DLzbx2ciJLRceS/EiIl9/X6a+e8A/nqEdxiNX
2peaVhBtZhtgckwtIsXqN/VbEo6izg4Uf01Lfav5IGh7j8eo2xT+uNa/l6sYI9LX/HtY5UvVh5fz
oalLcK9KJZdmbam5V6LF0LswzyXTfHodxeW3iSX9Qerp02YDmtRMochuTE7ZWUMWP1+i1Jw4yAPA
2/hQrKpA3SQgSocAibeMYHSowRQUShkMoCaw6sRuJPrJAv3WAfHa/HKq4ajoX7CFjgjDm2jPkrRP
aYN02NiqcaK30Bq5INfg3M3c8W+mVwu+VQNY+9sBUjmwIuegT460hvnGjfszb7HB84aIunD8G606
7fWZv5VYAQPCR2fkLcURn0Z5r+qGNh4zlio2wa6ilQCERYkpqYIPbbkJMorqzR56gteYqkFUyZBN
ZOT9oLycVsOj6dUhWQqxpLSuUSTCH/SGG3q/S6HFMlD5H2HHljYkYEqqRhk9VUNWkPnCEXdWeZkq
DVj9ZuPK2MFRJ6jt/RF4Vx4NT3ZZRS62LAZW/pO4lbS1r24Hr1NltE/4XZDoHpbh0QYBucij/R00
RzMqicMiAt58X6eJLW33Yr7Ldk9zmjlKdQSP+2T3COqGU/m9+GOKUBwLYrfyKQfB12IF9lQm4EWT
2XVDnu0lGgWQHMi53ipI65IxOTRY7OxTLWeSGjB0cPGVweNGKE74DevqJfZw83tIfnydS+Ggw6JY
lOLSTTxlWgADgT4kiPn2JNsfIFAbnunSwertWpBXZq5CUD9ZZqxMV4HHTP21LkM4BCKO6brYXqb5
iN5ip7EAyn5QxcxxlRVw/vcYhgjSQzk8nXoCzLIaeEa+dfHdDVauAz/a216vyFm6+Auvw7nuYCDK
Fb9wkn788Jep3EXmOjitPI2mnAmwvO/DRLqXj6F/L6qJtfTao9J7SQrXz62EN0Y+zpG0vWnSRhms
AX/4aJFKs2n4Wf5E+Tw7qps0sL99A5RBLeD/5cyKdZAbLSP2adCjwNDK9caq7v+DhTcdtlIx9ah6
n9mHag4zL6kQFLs1reTs2vhJELb5G9d2qagkevmU2gQvTR7XOOL+hRFaa10+nRJc/awBfR9fln0n
bBCI6Nj2h5/FIQuoImgJMSxgXwaMFsu777KkHK3u9ia+7q0RIHYDcXy2Y9O/TkK9gwP5L6DIzN0v
kehl9oGeEhPAhgatn6m9L7ambXcJEmXnBLLvlPcnkx6WOmHUjooatn7hqPqNevJLQUx0YbJ+uAJB
DZAFjh916xRtd67DrQGgMjSSaLmpMER9hQH9yZWUfY/ZntU9UuTE89x/wV84AMP2DFPzXPRTCHQL
IMbJEbGXC2XjoWDJAKaZVZPRP2HKaRvJjKvFsbRuldH2PTc0eB2yuPPIiSNlP4aE4uJBoE0gRCky
cq6S7+9oBjJPl6QUoxbF4/IOUd9s8fbm/0XXjcYOj2MDKrGpDrj4HPj+LegQLfIiQ76S96JMvFfZ
2p+rXvT/1FK95EmMIKlFwF+V7Xs6bqYGqx6EhAHiegkNkjZOXhv017mbKfn1VIRnpY+OU45/Julm
Hje7dkKtEknSmxsqUao+P8B28naYV8Mm3YJGyu/Fj1+do95i/mfEdhxZ5hZSIoieN98DuTQooELu
EkWl/UHuEtXuGxhTmuXw2vdxxjMI+gMKFrVNQp0AI5mF4bcvk/0FPHVQAbWQsElbZ9QVG2BnvHpS
K9X1M1O4603mfV0B9uC6Ph6fbCeZFMdqX7Aw1ogaPP8AU0zo/prKkCiBeFtgqqyYWBqOovm+iYUx
P9iBzyQFsjoLmMgTN+7CCrkEG4vDYY6NTjoFMgovc4zT6StUcHGbgpzoLH/c/fKM1agJ19aS2Pdg
2tKbQ3rMCxmYuGk3eTJq8tI7lRqRcH9OYaS6C3fmhRtFvglnP2+VUO7QuBtT7/VRYlnaiqeq5b8f
hW46x+eX+dlJwPGbO+Mr3DoUdMim5lyhUKP5q5x0Vga65lMnZ+piu7CqfNPfmu0r2Z8AH0/7RVlz
xGLSh/zGwVlculNXrXb1SxT/7oaPdZ8BDLfNz9tLfsKxjsbY1c9HtEfAU+edQ0NGYFxBIMwt8amB
wbvYHupzCXVq9jRV3fLXeKKgCEq1CCBqyJyOjiNj+XG/v7irPRGcRjnFzHrOTApPMKCU5HE9f64K
qiZfqgC+v3y2yDOdYlpQQrLKz+f91x19QfOqsL5Wy6HWKdQJfv2kdbSolTfkl9R0FPlrYFLxAhEo
ismCdKkjthrRstmZp5BDB94G+k7obuSKQvHW/j7Tfxn6yub+q7u5u2w6p3f6gGsOwvATDC49Ctau
g54u9rIEn4STT6jSCPiNukJ0Pd8PVEcesvs4YKFkPd+AvDjCjGrR8hemgMyo6419tyY/mnKSFqEF
4rOCnwkcdbGeg0IqkU282xNIcisHnzMMLCYX+u6CQYz66QIxxw5UULaS9M3d4fsqrwVOnULzHjhe
sZNaqr+wR4jAr0==